package network.conet.chat

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Native Conet Chat module — WorkerCommand / WorkerOutbound parity with
 * `@conet.project/chat-sdk`, model 1B signing (the host PWA signs, see
 * [BeamioConetChatSignBroker]).
 *
 * Wire contract (same as the iOS `ConetChatSDK`):
 *  - PWA → native: `handleCommand({ type, reqId, … })`
 *  - native → PWA: `{ action: "chatModuleEvent", event: { type: "ready" | "ack" | "event:*", … } }`
 *    and `{ action: "chatModuleSignRequest", … }` (through the same emitter).
 */
object BeamioConetChatModule {
    private const val TAG = "BeamioConetChat"

    /** Entry / mailbox node with optional route PGP (from the PWA `setNodes`). */
    data class Node(
        val ip: String,
        val domain: String,
        val region: String,
        val armoredPublicKey: String,
    ) {
        fun asStoreNode() = BeamioChatPgpStore.SiNode(ip, domain, region)
    }

    class Session {
        @Volatile var eoa: String = ""
        @Volatile var pgpPrivateKeyArmored: String = ""
        @Volatile var pgpPublicKeyArmored: String = ""
        @Volatile var pgpPassphrase: String = ""
        @Volatile var ownRouteArmoredPublicKey: String = ""
        @Volatile var mailboxIp: String = ""
        @Volatile var nodes: List<Node> = emptyList()
        @Volatile var routes: List<JSONObject> = emptyList()
        @Volatile var conetRpcUrl: String = "https://rpc1.conet.network"
        @Volatile var ipfsBaseUrl: String = "https://ipfs.conet.network/api"
        @Volatile var ipfsWriteBaseUrl: String = ""
        @Volatile var apiBaseUrl: String = "https://beamio.app/api"
        @Volatile var chatIndexRegistryAddress: String = "0x1511Caa71081C84d8a591490D1b83879088EED72"
        @Volatile var chainId: Int = 224422
        @Volatile var history: BeamioConetChatHistoryStore? = null
        @Volatile var destroyed: Boolean = false
        /**
         * The app confirms each inbound message with `ackInbound` after it has
         * stored it. Until then the mailbox keeps its offline copy, so a message
         * is not lost when the page is starting, suspended or killed.
         */
        @Volatile var deferAck: Boolean = false
        val pendingAcks = java.util.concurrent.ConcurrentHashMap<String, PendingAck>()
    }

    class PendingAck(val plaintext: String, val from: String, val viaDomain: String, val at: Long)

    private val lock = Any()
    private var session: Session? = null
    private var appContext: Context? = null

    @Volatile
    private var emitFn: ((JSONObject) -> Unit)? = null
    private val listen = BeamioConetChatListenSession()
    private val voiceSessions = HashSet<String>()
    private val seenArmor = object : LinkedHashMap<String, Boolean>(256, 0.75f, false) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?): Boolean = size > 512
    }
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newCachedThreadPool { r ->
        Thread(r, "conet-chat-module").apply { isDaemon = true }
    }

    /**
     * Shell hook: sees every module event (messages included) even when no page
     * is attached, so the shell can act on a caller's cancel natively. Main thread.
     */
    @Volatile
    @JvmField
    var nativeObserver: ((JSONObject) -> Unit)? = null

    /**
     * Shell hook: `true` while a call rings or is up. The page's background
     * `pause` is then deferred: the mailbox listen stays connected until the call ends.
     */
    @Volatile
    @JvmField
    var keepListenWhile: (() -> Boolean)? = null

    /**
     * Shell call layer: a verified peer call-control message arrived over Chat
     * (type, callId, sessionId, recovered signer). Main thread.
     */
    @Volatile
    @JvmField
    var callControlObserver: ((type: String, callId: String, sessionId: String, from: String) -> Unit)? = null

    /** A pause is owed once [keepListenWhile] turns false. Main thread. */
    private var pauseOwed = false
    private var idleCheckPosted = false
    private const val IDLE_CHECK_MS = 10_000L

    fun isAvailable(): Boolean = true

    fun isRunning(): Boolean = synchronized(lock) { session != null } && listen.isRunning()

    /**
     * Entry point for every PWA command. [emit] delivers payloads to the web layer
     * (the shell dispatches them as a `cashtreesandroid` `CustomEvent`).
     */
    fun handleCommand(context: Context, body: JSONObject, emit: (JSONObject) -> Unit) {
        appContext = context.applicationContext
        emitFn = emit
        BeamioConetChatSignBroker.setEmit(emit)
        when (val type = body.optString("type", "")) {
            "init" -> handleInit(body)
            "setRoutes" -> currentSession()?.let { s -> body.optJSONArray("routes")?.let { s.routes = objects(it) } }
            "setNodes" -> currentSession()?.let { s -> body.optJSONArray("nodes")?.let { s.nodes = parseNodes(it) } }
            "nodesResponse" -> Unit
            "send" -> handleSend(body)
            "sendGroup", "issueGroupRoster", "issueGroupTombstone" -> handleGroup(body)
            "queryPresence" -> handleQueryPresence(body)
            "queryNativeWake" -> handleQueryNativeWake(body)
            "historyLoad" -> handleHistoryLoad(body)
            "historyRead" -> handleHistoryRead(body)
            "historyAppend" -> handleHistoryAppend(body)
            "mailboxCommand" -> handleMailboxCommand(body)
            "ownMailboxCommand" -> {
                currentSession()?.let { body.put("routerArmoredPublicKey", it.ownRouteArmoredPublicKey) }
                handleMailboxCommand(body)
            }
            "voiceFrame" -> handleVoiceFrame(body)
            "voiceListen" -> handleVoiceListen(body)
            "voiceUnlisten" -> handleVoiceUnlisten(body)
            "pause" -> main.post { requestPause() }
            "ackInbound" -> handleAckInbound(body)
            "resume" -> {
                main.post { pauseOwed = false }
                resumeListen()
            }
            "destroy" -> destroy()
            "clearIdentity" -> clearIdentity(body.optInt("reqId", -1))
            "provisionIdentity" -> provisionIdentity(body)
            else -> Log.w(TAG, "unknown command $type")
        }
    }

    /** PWA answered a `chatModuleSignRequest`. */
    fun fulfillSign(body: JSONObject) = BeamioConetChatSignBroker.fulfill(body)

    // ---- init / routes / nodes -----------------------------------------------------

    private fun handleInit(body: JSONObject) {
        val reqId = body.optInt("reqId", 0)
        val ctx = appContext ?: return
        val payload = body.optJSONObject("payload")
        if (payload == null) {
            ack(reqId, false, error = "missing_payload")
            return
        }
        val idEoa = payload.optJSONObject("identity")?.let { id ->
            normalizeAddress(id.optString("eoaAddress", "").ifBlank { id.optString("eoa", "") })
        }.orEmpty()
        val walletKey = BeamioChatWalletKeyStore.normalizeKey(
            payload.optJSONObject("identity")?.optString("privateKeyHex", ""),
        )
        // A listen started without the page (call push) for this wallet: the page
        // takes it over as it is. No reconnect, and the messages it holds unconfirmed
        // are handed to the page below.
        val running = currentSession()
        val attach = running != null && idEoa.isNotEmpty() && running.eoa == idEoa && listen.isActive()
        val s = if (attach) running!! else Session()
        if (!attach) {
            synchronized(lock) {
                listen.stop()
                session?.history?.destroy()
                session = s
            }
        }
        main.post { pauseOwed = false }
        s.deferAck = payload.optBoolean("deferAck", false) || (attach && s.deferAck)
        if (s.deferAck && !attach) {
            // A new page has seen nothing: let the mailbox's redelivery of
            // messages the previous page never confirmed reach it again.
            synchronized(seenArmor) { seenArmor.clear() }
        }

        payload.optJSONObject("identity")?.let { id ->
            s.eoa = normalizeAddress(id.optString("eoaAddress", "").ifBlank { id.optString("eoa", "") })
            s.pgpPrivateKeyArmored = id.optString("pgpPrivateKeyArmored", "")
            s.pgpPublicKeyArmored = id.optString("pgpPublicKeyArmored", "")
            s.pgpPassphrase = id.optString("pgpPassphrase", "")
            s.ownRouteArmoredPublicKey = id.optString("ownRouteArmoredPublicKey", "")
                .ifBlank { id.optString("routePublicKeyArmored", "") }
            s.mailboxIp = id.optString("mailboxIp", "")
        }
        if (s.pgpPrivateKeyArmored.isEmpty() || s.ownRouteArmoredPublicKey.isEmpty()) {
            BeamioChatPgpStore.load(ctx)?.let { kc ->
                if (s.pgpPrivateKeyArmored.isEmpty()) s.pgpPrivateKeyArmored = kc.privateKeyArmor
                if (s.pgpPublicKeyArmored.isEmpty()) s.pgpPublicKeyArmored = kc.publicKeyArmor
                if (s.ownRouteArmoredPublicKey.isEmpty()) s.ownRouteArmoredPublicKey = kc.routePublicKeyArmor
                if (s.mailboxIp.isEmpty()) s.mailboxIp = kc.mailboxIp
                if (s.eoa.isEmpty()) s.eoa = normalizeAddress(kc.eoa)
            }
        }
        s.conetRpcUrl = payload.optString("conetRpcUrl", "").ifBlank { s.conetRpcUrl }
        s.ipfsBaseUrl = payload.optString("ipfsBaseUrl", "").ifBlank { s.ipfsBaseUrl }
        s.ipfsWriteBaseUrl = payload.optString("ipfsWriteBaseUrl", "")
        s.apiBaseUrl = payload.optString("apiBaseUrl", "").ifBlank { s.apiBaseUrl }
        s.chatIndexRegistryAddress = payload.optString("chatIndexRegistryAddress", "")
            .ifBlank { s.chatIndexRegistryAddress }
        if (payload.has("chainId")) s.chainId = payload.optInt("chainId", s.chainId)

        val nodesRaw = payload.optJSONArray("nodes")
        if (nodesRaw != null) {
            s.nodes = parseNodes(nodesRaw)
        } else {
            val saved = BeamioChatPgpStore.loadSiNodes(ctx)
            if (saved.isNotEmpty()) s.nodes = saved.map { Node(it.ip, it.domain, it.region, "") }
        }
        payload.optJSONArray("routes")?.let { s.routes = objects(it) }

        if (s.eoa.isEmpty() || !s.pgpPrivateKeyArmored.contains("BEGIN PGP PRIVATE KEY")) {
            ack(reqId, false, error = "missing_identity")
            return
        }

        // Keep the killed-app voice path working: it reads the PGP key / route / roster from here.
        try {
            BeamioChatPgpStore.upsertFromWeb(
                ctx,
                JSONObject()
                    .put("privateKeyArmor", s.pgpPrivateKeyArmored)
                    .put("publicKeyArmor", s.pgpPublicKeyArmored)
                    .put("routePublicKeyArmor", s.ownRouteArmoredPublicKey)
                    .put("eoa", s.eoa),
            )
            if (s.nodes.isNotEmpty() && BeamioChatPgpStore.loadSiNodes(ctx).isEmpty()) {
                BeamioChatPgpStore.storeChainRoster(ctx, s.nodes.map { it.asStoreNode() }, s.mailboxIp.ifBlank { null })
            }
        } catch (e: Exception) {
            Log.w(TAG, "persist identity: ${e.message}")
        }

        val host = BeamioOpenPgpHost.shared(ctx)
        host.ensureReady { ok ->
            if (!ok) {
                ack(reqId, false, error = "openpgp_not_ready")
                return@ensureReady
            }
            adoptWalletKey(ctx, host, s.eoa, walletKey) { finishInit(ctx, reqId, s, attach) }
        }
    }

    /**
     * Sign locally from now on. A key from the page is checked against the
     * session wallet and stored; without one, a stored key for the same wallet
     * is used; otherwise signing falls back to the page.
     */
    private fun adoptWalletKey(
        ctx: Context,
        host: BeamioOpenPgpHost,
        eoa: String,
        walletKey: String,
        done: () -> Unit,
    ) {
        if (walletKey.isEmpty()) {
            val stored = BeamioChatWalletKeyStore.load(ctx)
            if (stored != null && stored.eoa == eoa) {
                BeamioConetChatSignBroker.setLocalSigner(host, stored.privateKeyHex)
            } else {
                // Another wallet's key must not stay behind after a switch.
                if (stored != null) BeamioChatWalletKeyStore.clear(ctx)
                BeamioConetChatSignBroker.clearLocalSigner()
            }
            done()
            return
        }
        host.walletAddress(walletKey) { addr ->
            if (addr.getOrNull() == eoa) {
                val saved = BeamioChatWalletKeyStore.save(ctx, eoa, walletKey)
                BeamioConetChatSignBroker.setLocalSigner(host, walletKey)
                Log.i(TAG, "wallet signer local stored=$saved")
            } else {
                Log.w(TAG, "wallet key does not match the session wallet; page signs")
                BeamioConetChatSignBroker.clearLocalSigner()
            }
            done()
        }
    }

    private fun finishInit(ctx: Context, reqId: Int, s: Session, attach: Boolean) {
        run {
            val history = BeamioConetChatHistoryStore(
                eoa = s.eoa,
                chainId = s.chainId,
                conetRpcUrl = s.conetRpcUrl,
                ipfsBaseUrl = s.ipfsBaseUrl,
                ipfsWriteBaseUrl = s.ipfsWriteBaseUrl.ifBlank { null },
                apiBaseUrl = s.apiBaseUrl,
                registryAddress = s.chatIndexRegistryAddress,
                log = { level, msg ->
                    // Shape only (counts / short cid) — never plaintext or key material.
                    Log.i(TAG, msg)
                    emitEvent(JSONObject().put("type", "event:log").put("level", level).put("message", msg))
                },
            )
            s.history?.destroy()
            s.history = history
            // Listen first: it must not wait on the (sign-dependent) history key derivation.
            emitEvent(JSONObject().put("type", "ready").put("reqId", reqId))
            if (attach) {
                Log.i(TAG, "page attached to the running listen pending=${s.pendingAcks.size}")
                if (listen.isRunning()) emitStatus("listening", "attached") else resumeListen()
                for ((hash, p) in s.pendingAcks.entries.toList()) {
                    emitInboundMessage(p.plaintext, p.from, hash, p.viaDomain)
                }
            } else {
                startListen(ctx, s)
            }
            if (s.deferAck) replayInbox(ctx, s)
            history.prepare { }
        }
    }

    // ---- no-page start (call push) -----------------------------------------------------

    /**
     * Open the mailbox listen from the stored identity, without the page: a call
     * push woke the app. Messages are handed to [nativeObserver] and kept
     * unconfirmed (no mailbox ACK) until the page starts and stores them. When a
     * session already exists it is only resumed. Returns false when no stored
     * identity can listen (no wallet key, PGP key, route key or roster).
     */
    fun startFromStore(context: Context, reason: String): Boolean {
        val ctx = context.applicationContext
        appContext = ctx
        currentSession()?.let { existing ->
            if (listen.isRunning() && !listenConnected) {
                // Reconnecting (e.g. the network was blocked in the background):
                // retry now instead of waiting out the backoff.
                Log.i(TAG, "listen not connected; retrying now for $reason")
                startListen(ctx, existing)
            } else if (!listen.isRunning()) {
                Log.i(TAG, "listen resumed for $reason")
                // Paused by the page in the background: pause again after the call.
                main.post {
                    pauseOwed = true
                    postIdleCheck()
                }
                listen.resume(ctx, existing, onStatus = { st, d -> emitStatus(st, d) }, onInbound = { p, h, v, a -> handleInbound(p, h, v, a) })
            }
            return true
        }
        val pgp = BeamioChatPgpStore.load(ctx)
        val wallet = BeamioChatWalletKeyStore.load(ctx)
        if (pgp == null || !pgp.hasUserPrivate || !pgp.hasRoutePublic || wallet == null) {
            Log.w(TAG, "no stored identity for a no-page listen ($reason)")
            return false
        }
        if (pgp.eoa.isNotBlank() && normalizeAddress(pgp.eoa) != wallet.eoa) {
            Log.w(TAG, "stored PGP and wallet belong to different wallets; no-page listen skipped")
            return false
        }
        val nodes = BeamioChatPgpStore.loadSiNodes(ctx)
        if (nodes.isEmpty()) {
            Log.w(TAG, "no stored roster for a no-page listen ($reason)")
            return false
        }
        val s = Session().apply {
            eoa = wallet.eoa
            pgpPrivateKeyArmored = pgp.privateKeyArmor
            pgpPublicKeyArmored = pgp.publicKeyArmor
            ownRouteArmoredPublicKey = pgp.routePublicKeyArmor
            mailboxIp = pgp.mailboxIp
            this.nodes = nodes.map { Node(it.ip, it.domain, it.region, "") }
            deferAck = true
        }
        synchronized(lock) {
            if (session != null) return true
            session = s
        }
        Log.i(TAG, "no-page listen starting for $reason")
        val host = BeamioOpenPgpHost.shared(ctx)
        host.ensureReady { ok ->
            if (!ok || currentSession() !== s) return@ensureReady
            BeamioConetChatSignBroker.setLocalSigner(host, wallet.privateKeyHex)
            startListen(ctx, s)
        }
        main.post {
            pauseOwed = true
            postIdleCheck()
        }
        return true
    }

    // ---- background pause vs. calls ------------------------------------------------------

    /** Main thread. */
    private fun requestPause() {
        if (keepListenWhile?.invoke() == true) {
            Log.i(TAG, "pause deferred: call in progress")
            pauseOwed = true
            postIdleCheck()
            return
        }
        pauseOwed = false
        listen.pause()
        emitEvent(JSONObject().put("type", "event:status").put("payload", statusPayload("idle", "paused")))
    }

    /** Main thread. */
    private fun postIdleCheck() {
        if (idleCheckPosted) return
        idleCheckPosted = true
        main.postDelayed({
            idleCheckPosted = false
            if (!pauseOwed) return@postDelayed
            if (keepListenWhile?.invoke() == true) {
                postIdleCheck()
            } else {
                Log.i(TAG, "call over; owed pause applied")
                requestPause()
            }
        }, IDLE_CHECK_MS)
    }

    /** Logout / wallet removed or switched: stop and forget the stored keys. */
    private fun clearIdentity(reqId: Int) {
        val ctx = appContext
        destroy()
        BeamioConetChatSignBroker.clearLocalSigner()
        if (ctx != null) {
            BeamioChatWalletKeyStore.clear(ctx)
            BeamioChatPgpStore.clear(ctx)
            BeamioConetChatInboxStore.clear(ctx)
        }
        Log.i(TAG, "identity cleared")
        ack(reqId, true, result = JSONObject().put("ok", true))
    }

    /**
     * Hand the page what the inbox store holds and the page has not been given
     * in this session (received while it was not running, or never confirmed).
     */
    private fun replayInbox(ctx: Context, s: Session) {
        val stored = BeamioConetChatInboxStore.list(ctx).filter { !s.pendingAcks.containsKey(it.armorHash) }
        if (stored.isEmpty()) return
        Log.i(TAG, "inbox replay count=${stored.size}")
        for (e in stored) {
            synchronized(seenArmor) { seenArmor.remove(e.armorHash) }
            BeamioConetChatListenSession.decryptArmor(ctx, s, e.armor) { line, hash ->
                handleInbound(line, hash, e.viaDomain, e.armor)
            }
        }
    }

    /**
     * `provisionIdentity`: the page hands over the wallet key and PGP key. The
     * wallet key must match `eoa`; both go to secure storage (refused, not
     * stored, when that fails). Later listens sign locally.
     */
    private fun provisionIdentity(body: JSONObject) {
        val reqId = body.optInt("reqId", -1)
        val ctx = appContext ?: return
        val p = body.optJSONObject("payload") ?: body
        val eoa = normalizeAddress(p.optString("eoa", "").ifBlank { p.optString("eoaAddress", "") })
        val walletKey = BeamioChatWalletKeyStore.normalizeKey(
            p.optString("walletPrivateKey", "").ifBlank { p.optString("privateKeyHex", "") },
        )
        val pgpPrivate = p.optString("pgpPrivateKeyArmored", "")
        if (eoa.isEmpty() || walletKey.isEmpty() || !pgpPrivate.contains("BEGIN PGP PRIVATE KEY")) {
            ack(reqId, false, error = "bad_identity")
            return
        }
        val pgpOk = BeamioChatPgpStore.upsertFromWeb(
            ctx,
            JSONObject()
                .put("privateKeyArmor", pgpPrivate)
                .put("publicKeyArmor", p.optString("pgpPublicKeyArmored", ""))
                .put("routePublicKeyArmor", p.optString("ownRoute", "").ifBlank { p.optString("ownRouteArmoredPublicKey", "") })
                .put("eoa", eoa),
        )
        val host = BeamioOpenPgpHost.shared(ctx)
        host.ensureReady { ok ->
            if (!ok) {
                ack(reqId, false, error = "openpgp_not_ready")
                return@ensureReady
            }
            host.walletAddress(walletKey) { addr ->
                if (addr.getOrNull() != eoa) {
                    ack(reqId, false, error = "wallet_mismatch")
                    return@walletAddress
                }
                val saved = BeamioChatWalletKeyStore.save(ctx, eoa, walletKey)
                if (saved && pgpOk) BeamioConetChatSignBroker.setLocalSigner(host, walletKey)
                Log.i(TAG, "identity provisioned stored=${saved && pgpOk}")
                if (saved && pgpOk) ack(reqId, true, result = JSONObject().put("ok", true))
                else ack(reqId, false, error = "secure_store_failed")
            }
        }
    }

    // ---- call layer entry (no page involved) ----------------------------------------------

    /**
     * Native call layer: a call push arrived, a call rings or is up, or the app
     * came to the foreground. Opens / resumes the mailbox listen from the stored
     * identity. Same as [startFromStore].
     */
    fun wake(context: Context, reason: String): Boolean = startFromStore(context, reason)

    /** Native call layer: the call is over. Applies an owed background pause now. */
    fun release(reason: String) {
        main.post {
            if (pauseOwed && keepListenWhile?.invoke() != true) {
                Log.i(TAG, "released ($reason); owed pause applied")
                requestPause()
            }
        }
    }

    // ---- send ---------------------------------------------------------------------

    private fun handleSend(body: JSONObject) {
        val reqId = body.optInt("reqId", 0)
        val ctx = appContext
        val s = currentSession()
        val to = body.optJSONObject("to")
        if (ctx == null || s == null || to == null) {
            ack(reqId, false, error = "not_ready")
            return
        }
        val payload = body.optString("payload", "")
        val sendId = body.optString("sendId", "").ifBlank { UUID.randomUUID().toString() }
        val noPush = body.optBoolean("beamioNoPush", false)
        val userPgp = to.optString("userPublicKeyArmored", "").trim()
        val mailboxRoute = to.optString("routerArmoredPublicKey", "").trim()
        if (!userPgp.contains("BEGIN PGP PUBLIC KEY")) {
            ack(reqId, false, error = "missing_recipient_pgp")
            return
        }
        if (noPush && !mailboxRoute.contains("BEGIN PGP PUBLIC KEY")) {
            ack(reqId, false, error = "NoPush requires recipient mailbox routerArmoredPublicKey")
            return
        }
        val host = BeamioOpenPgpHost.shared(ctx)
        BeamioConetChatSignBroker.requestEip191(payload) { signResult ->
            val signature = signResult.getOrElse {
                ack(reqId, false, error = it.message ?: "sign_failed")
                return@requestEip191
            }
            val envelope = JSONObject()
                .put("timestamp", System.currentTimeMillis())
                .put("text", payload)
                .put("from", s.eoa)
                .put("signMessage", signature)
            host.encryptUtf8JsonBase64(envelope.toString(), userPgp) { enc ->
                val armor = enc.getOrElse {
                    ack(reqId, false, error = it.message ?: "encrypt_failed")
                    return@encryptUtf8JsonBase64
                }
                val finish = { finalArmor: String ->
                    io.execute {
                        val ok = postToEntries(ctx, finalArmor, mailboxRoute, s)
                        ack(reqId, true, result = JSONObject().put("sent", ok).put("sendId", sendId))
                    }
                }
                if (noPush) {
                    host.wrapArmorToMailboxWork(armor, mailboxRoute, true) { wrapped ->
                        wrapped.fold(
                            onSuccess = { finish(it) },
                            onFailure = { ack(reqId, false, error = it.message ?: "wrap_failed") },
                        )
                    }
                } else {
                    finish(armor)
                }
            }
        }
    }

    private fun handleGroup(body: JSONObject) {
        val reqId = body.optInt("reqId", 0)
        val ctx = appContext
        val s = currentSession()
        val request = body.optJSONObject("request")
        val members = request?.optJSONObject("roster")?.optJSONArray("members")
        if (ctx == null || s == null || request == null || members == null || members.length() == 0) {
            // Roster / tombstone requests without members are acknowledged as a no-op.
            ack(reqId, true, result = JSONObject().put("ok", true))
            return
        }
        val text = request.optString("body", "").ifBlank { request.optString("text", "") }
        val groupId = request.optString("groupId", "")
            .ifBlank { request.optJSONObject("roster")?.optString("groupId", "").orEmpty() }
        val host = BeamioOpenPgpHost.shared(ctx)
        BeamioConetChatSignBroker.requestEip191(text) { signResult ->
            val signature = signResult.getOrElse {
                ack(reqId, false, error = "group_sign_failed")
                return@requestEip191
            }
            val envelope = JSONObject()
                .put("timestamp", System.currentTimeMillis())
                .put("text", text)
                .put("from", s.eoa)
                .put("signMessage", signature)
                .put("groupId", groupId)
            io.execute {
                var delivered = 0
                val latch = CountDownLatch(members.length())
                for (i in 0 until members.length()) {
                    val member = members.optJSONObject(i)
                    val pgp = member?.optString("userPublicKeyArmored", "")
                        ?.ifBlank { member.optString("pgpPublicKeyArmored", "") }.orEmpty()
                    val route = member?.optString("routerArmoredPublicKey", "").orEmpty()
                    if (!pgp.contains("BEGIN PGP PUBLIC KEY")) {
                        latch.countDown()
                        continue
                    }
                    host.encryptUtf8JsonBase64(envelope.toString(), pgp) { enc ->
                        io.execute {
                            try {
                                val armor = enc.getOrNull()
                                if (armor != null && postToEntries(ctx, armor, route, s)) {
                                    synchronized(this) { delivered += 1 }
                                }
                            } finally {
                                latch.countDown()
                            }
                        }
                    }
                }
                latch.await(60, TimeUnit.SECONDS)
                ack(reqId, true, result = JSONObject().put("delivered", delivered).put("members", members.length()))
            }
        }
    }

    // ---- presence / native wake ---------------------------------------------------

    private fun handleQueryPresence(body: JSONObject) {
        val reqId = body.optInt("reqId", 0)
        val s = currentSession()
        if (s == null) {
            ack(reqId, false, error = "not_ready")
            return
        }
        val contacts = body.optJSONArray("contacts")?.let { objects(it) }.orEmpty()
        if (contacts.isEmpty()) {
            ack(reqId, true, result = JSONObject())
            return
        }
        io.execute {
            val result = JSONObject()
            val latch = CountDownLatch(contacts.size)
            for (c in contacts) {
                val target = normalizeAddress(c.optString("address", "").ifBlank { c.optString("eoaAddress", "") })
                val route = c.optString("routerArmoredPublicKey", "")
                if (target.isEmpty() || !route.contains("BEGIN PGP PUBLIC KEY")) {
                    latch.countDown()
                    continue
                }
                postSignedMailboxCommand(
                    s, route,
                    JSONObject().put("command", "wallet_online_query").put("targetWallet", target),
                ) { ok, json ->
                    try {
                        if (ok && json != null && json.optBoolean("ok", false)) {
                            val online = json.optBoolean("online", false)
                            synchronized(result) { result.put(target, online) }
                            emitEvent(
                                JSONObject().put("type", "event:presence").put(
                                    "payload",
                                    JSONObject().put("wallet", target).put("online", online).put("ok", true),
                                ),
                            )
                        }
                    } finally {
                        latch.countDown()
                    }
                }
            }
            latch.await(30, TimeUnit.SECONDS)
            ack(reqId, true, result = result)
        }
    }

    private fun handleQueryNativeWake(body: JSONObject) {
        val reqId = body.optInt("reqId", 0)
        val s = currentSession()
        val contact = body.optJSONObject("contact")
        if (s == null || contact == null) {
            ack(reqId, false, error = "not_ready")
            return
        }
        val target = normalizeAddress(contact.optString("address", "").ifBlank { contact.optString("eoaAddress", "") })
        val route = contact.optString("routerArmoredPublicKey", "")
        if (target.isEmpty() || !route.contains("BEGIN PGP PUBLIC KEY")) {
            ack(reqId, false, error = "bad_native_wake")
            return
        }
        postSignedMailboxCommand(
            s, route,
            JSONObject().put("command", "wallet_native_wake_query").put("targetWallet", target),
        ) { ok, json ->
            if (ok && json != null && json.optBoolean("ok", false)) {
                ack(
                    reqId, true,
                    result = JSONObject().put("ok", true).put("wallet", target)
                        .put("nativeWakeable", json.optBoolean("nativeWakeable", false)),
                )
            } else {
                ack(reqId, true, result = JSONObject().put("ok", false).put("wallet", target))
            }
        }
    }

    // ---- history ------------------------------------------------------------------

    private fun handleHistoryLoad(body: JSONObject) {
        val reqId = body.optInt("reqId", 0)
        val hist = currentSession()?.history
        if (hist == null || !hist.isReady()) {
            // History key derivation (a PWA signature) may still be in flight: not an error.
            ack(reqId, true, result = JSONObject.NULL)
            return
        }
        hist.load(
            body.optJSONObject("options"),
            emitBuffer = { peer, entries, isTail ->
                emitEvent(
                    JSONObject().put("type", "event:historyBuffer").put(
                        "payload",
                        JSONObject()
                            .put("peer", peer)
                            .put("entries", JSONArray().also { arr -> entries.forEach { arr.put(it.toJson()) } })
                            .put("isTail", isTail),
                    ),
                )
            },
            done = { ack(reqId, true, result = JSONObject.NULL) },
        )
    }

    private fun handleHistoryRead(body: JSONObject) {
        val reqId = body.optInt("reqId", 0)
        val hist = currentSession()?.history
        if (hist == null || !hist.isReady()) {
            ack(reqId, true, result = JSONArray())
            return
        }
        hist.read(body.optJSONObject("options")) { entries ->
            ack(reqId, true, result = JSONArray().also { arr -> entries.forEach { arr.put(it.toJson()) } })
        }
    }

    private fun handleHistoryAppend(body: JSONObject) {
        val reqId = body.optInt("reqId", 0)
        val hist = currentSession()?.history
        val entry = body.optJSONObject("entry")
        if (hist == null || entry == null || !hist.isReady()) {
            ack(reqId, false, error = "history_not_ready")
            return
        }
        hist.append(entry) { ok ->
            ack(reqId, ok, result = JSONObject().put("ok", ok), error = if (ok) null else "append_failed")
        }
    }

    // ---- mailbox commands / voice ----------------------------------------------------

    private fun handleMailboxCommand(body: JSONObject) {
        val reqId = body.optInt("reqId", 0)
        val s = currentSession()
        if (s == null) {
            ack(reqId, false, error = "not_ready")
            return
        }
        val routeKey = body.optString("routerArmoredPublicKey", "")
        val command = body.optJSONObject("command")
        if (command == null || !routeKey.contains("BEGIN PGP PUBLIC KEY")) {
            ack(reqId, false, error = "bad_mailbox_command")
            return
        }
        // Voice commands never carry a wallet or wallet signature.
        if (command.optString("command", "").startsWith("voice_")) {
            postOpaqueVoiceCommand(s, routeKey, command) { ok ->
                ack(reqId, true, result = JSONObject().put("ok", ok))
            }
            return
        }
        postSignedMailboxCommand(s, routeKey, command) { ok, _ ->
            ack(reqId, true, result = JSONObject().put("ok", ok))
        }
    }

    private fun handleVoiceListen(body: JSONObject) {
        val reqId = body.optInt("reqId", 0)
        val sessionId = body.optString("sessionId", "")
        synchronized(lock) { voiceSessions.add(sessionId) }
        // The shell's native voice signaling owns the voice SSE — never open a second one.
        ack(reqId, true, result = JSONObject().put("ok", true).put("delegated", true).put("sessionId", sessionId))
    }

    private fun handleVoiceUnlisten(body: JSONObject) {
        val reqId = body.optInt("reqId", 0)
        synchronized(lock) { voiceSessions.remove(body.optString("sessionId", "")) }
        ack(reqId, true, result = JSONObject().put("ok", true))
    }

    private fun handleVoiceFrame(body: JSONObject) {
        val reqId = body.optInt("reqId", 0)
        val s = currentSession()
        if (s == null) {
            ack(reqId, false, error = "not_ready")
            return
        }
        val routeKey = body.optString("routerArmoredPublicKey", "")
        val frame = body.optJSONObject("frame")
        if (frame == null || !routeKey.contains("BEGIN PGP PUBLIC KEY")) {
            ack(reqId, false, error = "bad_voice_frame")
            return
        }
        val command = opaqueVoiceUplinkCommand(frame)
        if (command == null) {
            ack(reqId, false, error = "bad_voice_frame")
            return
        }
        postOpaqueVoiceCommand(s, routeKey, command) { ok ->
            ack(reqId, true, result = JSONObject().put("sent", ok))
        }
    }

    /**
     * Rebuild a PWA voice frame as the route command the peer's mailbox reads.
     *
     * Allow-list only: the PWA frame carries `to` (the peer wallet), and the relay
     * routes by session id alone (CoNET Chat protocol rules 18–21). Same shape as
     * the native shells and the PWA worker SDK send.
     */
    internal fun opaqueVoiceUplinkCommand(frame: JSONObject): JSONObject? {
        val callId = frame.optString("callId", "").trim()
        val sessionId = frame.optString("sessionId", "").trim()
        val targetSessionId = frame.optString("targetSessionId", "").trim()
        val payload = frame.optString("payload", "")
        val seq = frame.optLong("seq", -1L)
        if (callId.isEmpty() || sessionId.isEmpty() || targetSessionId.isEmpty() || payload.isEmpty() || seq < 0) {
            return null
        }
        val nowSec = System.currentTimeMillis() / 1000L
        val command = JSONObject()
            .put("command", "voice_uplink")
            .put("type", "voice_frame_v1")
            .put("callId", callId)
            .put("sessionId", sessionId)
            .put("targetSessionId", targetSessionId)
            .put("direction", frame.optString("direction", "").ifBlank { "uplink" })
            .put("seq", seq)
            .put("frameTimestamp", frame.opt("frameTimestamp") ?: frame.opt("timestamp") ?: nowSec)
            .put("payload", payload)
            .put("timestamp", nowSec)
        for (key in listOf("mediaKind", "frameId", "chunkIndex", "chunkCount")) {
            if (frame.has(key)) command.put(key, frame.get(key))
        }
        return command
    }

    /**
     * Voice route command: unsigned, no wallet. A wallet signature would let the
     * mailbox recover the sender's wallet, and the node does not ask for one
     * (sessionId is the capability). JSON → base64 → route PGP → entry ≠ B.
     */
    private fun postOpaqueVoiceCommand(
        s: Session,
        routerArmoredPublicKey: String,
        command: JSONObject,
        completion: (ok: Boolean) -> Unit,
    ) {
        val ctx = appContext
        if (ctx == null) {
            completion(false)
            return
        }
        val cmd = JSONObject(command.toString())
        for (key in listOf("walletAddress", "billingWallet", "from", "to")) cmd.remove(key)
        if (!cmd.has("timestamp")) cmd.put("timestamp", System.currentTimeMillis() / 1000)
        BeamioOpenPgpHost.shared(ctx).encryptUtf8JsonBase64(cmd.toString(), routerArmoredPublicKey) { enc ->
            val armor = enc.getOrNull()
            if (armor == null || !armor.contains("BEGIN PGP MESSAGE")) {
                completion(false)
                return@encryptUtf8JsonBase64
            }
            io.execute { completion(postToEntries(ctx, armor, routerArmoredPublicKey, s)) }
        }
    }

    // ---- listen lifecycle -------------------------------------------------------------

    private fun startListen(ctx: Context, s: Session) {
        listen.start(ctx, s, onStatus = { st, d -> emitStatus(st, d) }, onInbound = { p, h, v, a -> handleInbound(p, h, v, a) })
    }

    private fun resumeListen() {
        val ctx = appContext ?: return
        val s = currentSession() ?: return
        // Already connected (or reconnecting by itself): do not restart it.
        if (listen.isRunning()) return
        listen.resume(ctx, s, onStatus = { st, d -> emitStatus(st, d) }, onInbound = { p, h, v, a -> handleInbound(p, h, v, a) })
    }

    private fun destroy() {
        listen.stop()
        BeamioConetChatSignBroker.cancelAll("destroyed")
        synchronized(lock) {
            session?.destroyed = true
            session?.history?.destroy()
            session?.history = null
            session = null
            voiceSessions.clear()
        }
        emitEvent(JSONObject().put("type", "event:status").put("payload", statusPayload("destroyed", null)))
    }

    /** Last listen status was `listening` (connected). */
    @Volatile
    private var listenConnected = false

    private fun emitStatus(status: String, detail: String?) {
        listenConnected = status == "listening"
        emitEvent(JSONObject().put("type", "event:status").put("payload", statusPayload(status, detail)))
    }

    // ---- inbound + dual receipts -------------------------------------------------------

    private fun handleInbound(plaintext: String, armorHash: String, viaDomain: String, armor: String) {
        val ctx = appContext ?: return
        val s = currentSession() ?: return
        // The sender fans one message out to several entries; the mailbox then forwards each
        // copy. Identical armor (same keccak) is one message: no second event, no second receipt.
        if (armorHash.isNotEmpty() && !markSeen(armorHash)) {
            // Redelivered before the app confirmed it (page reloaded or was
            // suspended): hand it over again. The app deduplicates by sendId.
            val pending = s.pendingAcks[armorHash] ?: return
            emitInboundMessage(pending.plaintext, pending.from, armorHash, pending.viaDomain)
            return
        }
        verifyEnvelope(ctx, plaintext) { from ->
            if (from.isNullOrEmpty()) {
                emitEvent(
                    JSONObject().put("type", "event:log").put("level", "warn")
                        .put("message", "inbound verify failed — drop"),
                )
                return@verifyEnvelope
            }
            BeamioConetChatCallControl.parse(plaintext)?.let { sig ->
                main.post {
                    try {
                        callControlObserver?.invoke(sig.type, sig.callId, sig.sessionId, from)
                    } catch (e: Exception) {
                        Log.w(TAG, "call control observer failed: ${e.message}")
                    }
                }
            }
            if (s.deferAck && armorHash.isNotEmpty()) {
                prunePendingAcks(s)
                s.pendingAcks[armorHash] = PendingAck(plaintext, from, viaDomain, System.currentTimeMillis())
                // On disk until the app confirms it: survives the page not running.
                if (armor.isNotEmpty()) BeamioConetChatInboxStore.put(ctx, armorHash, armor, viaDomain)
                emitInboundMessage(plaintext, from, armorHash, viaDomain)
            } else {
                emitInboundMessage(plaintext, from, armorHash, viaDomain)
                emitDualReceipts(ctx, s, plaintext, armorHash, from)
            }
        }
    }

    private fun emitInboundMessage(plaintext: String, from: String, armorHash: String, viaDomain: String) {
        emitEvent(
            JSONObject().put("type", "event:message").put(
                "payload",
                JSONObject()
                    .put("line", plaintext)
                    .put("from", from)
                    .put("armorHash", armorHash)
                    .put("viaDomain", viaDomain)
                    .put("plain", false),
            ),
        )
    }

    /**
     * The app stored these messages: now send the mailbox ACK (deletes the
     * offline copy) and the sender's delivery receipt.
     */
    private fun handleAckInbound(body: JSONObject) {
        val ctx = appContext ?: return
        val s = currentSession() ?: return
        val hashes = ArrayList<String>()
        body.optJSONArray("armorHashes")?.let { arr ->
            for (i in 0 until arr.length()) arr.optString(i, "").takeIf { it.isNotBlank() }?.let { hashes.add(it) }
        }
        body.optString("armorHash", "").takeIf { it.isNotBlank() }?.let { hashes.add(it) }
        BeamioConetChatInboxStore.remove(ctx, hashes)
        for (hash in hashes) {
            val pending = s.pendingAcks.remove(hash) ?: continue
            emitDualReceipts(ctx, s, pending.plaintext, hash, pending.from)
        }
    }

    /** Unconfirmed for 10 minutes: forget it without ACK; the mailbox redelivers it later. */
    private fun prunePendingAcks(s: Session) {
        val cutoff = System.currentTimeMillis() - PENDING_ACK_TTL_MS
        val expired = s.pendingAcks.entries.filter { it.value.at < cutoff }.map { it.key }
        for (hash in expired) {
            s.pendingAcks.remove(hash)
            // Let the mailbox's redelivery through the dedupe again.
            synchronized(seenArmor) { seenArmor.remove(hash) }
        }
    }

    /**
     * Recover the EIP-191 signer. A claimed `from` that differs from the signer is passed on for the app to flag:
     * the recovered address is the only trusted sender identity.
     */
    private fun verifyEnvelope(ctx: Context, plaintext: String, completion: (String?) -> Unit) {
        val obj = try {
            JSONObject(plaintext)
        } catch (_: Exception) {
            completion(null)
            return
        }
        val text = when {
            obj.has("text") && obj.opt("text") is String -> obj.getString("text")
            obj.has("message") && obj.opt("message") is String -> obj.getString("message")
            else -> {
                completion(null)
                return
            }
        }
        val sig = obj.optString("signMessage", "")
        if (sig.isEmpty()) {
            completion(null)
            return
        }
        // The recovered signer is the sender. A claimed `from` that differs is
        // not dropped here: the app keeps the message under the signer and shows
        // a warning for the false claim.
        BeamioOpenPgpHost.shared(ctx).verifyMessage(text, sig) { result ->
            completion(result.getOrNull())
        }
    }

    /** Mailbox ACK (delete offline copy) + sender `beamio_chat_delivery_receipt_v1`. */
    private fun emitDualReceipts(ctx: Context, s: Session, plaintext: String, armorHash: String, from: String) {
        if (s.ownRouteArmoredPublicKey.contains("BEGIN PGP PUBLIC KEY")) {
            postSignedMailboxCommand(
                s, s.ownRouteArmoredPublicKey,
                JSONObject().put("command", "gossip_delivery_ack").put("armorHash", armorHash),
            ) { _, _ -> }
        }
        val fromLower = from.lowercase()
        val route = s.routes.firstOrNull {
            normalizeAddress(it.optString("address", "").ifBlank { it.optString("eoaAddress", "").ifBlank { it.optString("eoa", "") } }) == fromLower
        } ?: return
        if (!route.optString("userPublicKeyArmored", "").contains("BEGIN PGP PUBLIC KEY")) return

        val receipt = JSONObject()
            .put("type", "beamio_chat_delivery_receipt_v1")
            .put("sendId", extractSendId(plaintext).orEmpty())
            .put("armorHash", armorHash)
            .put("deliveredAt", System.currentTimeMillis())
            .put("from", s.eoa)
        val pending = JSONObject()
            .put("sendId", UUID.randomUUID().toString())
            .put("from", "me")
            .put("text", receipt.toString())
            .put("createdAt", System.currentTimeMillis())
        handleSend(
            JSONObject()
                .put("reqId", -1)
                .put("to", route)
                .put("payload", pending.toString())
                .put("sendId", UUID.randomUUID().toString())
                .put("beamioNoPush", true),
        )
    }

    // ---- shared helpers -----------------------------------------------------------------

    /** Sign (via the PWA) + encrypt a mailbox command to [routerArmoredPublicKey], POST via entry ≠ B. */
    private fun postSignedMailboxCommand(
        s: Session,
        routerArmoredPublicKey: String,
        command: JSONObject,
        completion: (ok: Boolean, json: JSONObject?) -> Unit,
    ) {
        val ctx = appContext
        if (ctx == null) {
            completion(false, null)
            return
        }
        val cmd = JSONObject(command.toString())
        if (!cmd.has("walletAddress")) cmd.put("walletAddress", s.eoa)
        if (!cmd.has("timestamp")) cmd.put("timestamp", System.currentTimeMillis() / 1000)
        val message = cmd.toString()
        BeamioConetChatSignBroker.requestEip191(message) { signResult ->
            val signature = signResult.getOrNull()
            if (signature == null) {
                completion(false, null)
                return@requestEip191
            }
            BeamioOpenPgpHost.shared(ctx).encryptSignedRouteCommand(message, signature, routerArmoredPublicKey) { enc ->
                val armor = enc.getOrNull()
                if (armor == null) {
                    completion(false, null)
                    return@encryptSignedRouteCommand
                }
                io.execute {
                    var json: JSONObject? = null
                    val ok = postToEntries(ctx, armor, routerArmoredPublicKey, s) { body ->
                        json = try {
                            JSONObject(body)
                        } catch (_: Exception) {
                            null
                        }
                    }
                    completion(ok, json)
                }
            }
        }
    }

    /**
     * POST via entry ≠ B (blocking). Wraps the armor to the entry route PGP when known, like the
     * TS gossip core (`outerWrap`). [onBody] receives the 2xx response body (mailbox JSON replies).
     */
    private fun postToEntries(
        ctx: Context,
        armor: String,
        mailboxRoute: String,
        s: Session,
        onBody: ((String) -> Unit)? = null,
    ): Boolean {
        val exclude = HashSet<String>()
        BeamioSiCipherPost.normalizeIp(s.mailboxIp)?.let { exclude.add(it) }
        if (mailboxRoute.contains("BEGIN PGP")) {
            for (n in s.nodes) {
                if (n.armoredPublicKey.isNotEmpty() &&
                    BeamioConetChatListenSession.fingerprintsOverlap(mailboxRoute, n.armoredPublicKey)
                ) {
                    BeamioSiCipherPost.normalizeIp(n.ip)?.let { exclude.add(it) }
                }
            }
        }
        val host = BeamioOpenPgpHost.shared(ctx)
        val candidates = s.nodes.filter { n ->
            val ip = BeamioSiCipherPost.normalizeIp(n.ip) ?: return@filter false
            ip !in exclude
        }.shuffled()

        for (entry in candidates.take(4)) {
            var postArmor = armor
            if (entry.armoredPublicKey.contains("BEGIN PGP PUBLIC KEY")) {
                val latch = CountDownLatch(1)
                host.wrapArmorToEntryRoute(armor, entry.armoredPublicKey) { r ->
                    r.getOrNull()?.let { postArmor = it }
                    latch.countDown()
                }
                latch.await(8, TimeUnit.SECONDS)
            }
            val result = BeamioSiCipherPost.post(postArmor, listOf(entry.asStoreNode()), exclude, maxAttempts = 1)
            if (result.ok) {
                onBody?.invoke(result.body)
                return true
            }
        }
        // Fallback: any roster node excluding the mailbox.
        val roster = s.nodes.map { it.asStoreNode() }
        val result = if (roster.isEmpty()) {
            BeamioSiCipherPost.post(armor, BeamioChatPgpStore.loadSiNodes(ctx), exclude)
        } else {
            BeamioSiCipherPost.post(armor, roster, exclude)
        }
        if (result.ok) onBody?.invoke(result.body)
        return result.ok
    }

    /** `true` the first time [armorHash] is seen (bounded, last 512). */
    private const val PENDING_ACK_TTL_MS = 10 * 60 * 1000L

    private fun markSeen(armorHash: String): Boolean = synchronized(seenArmor) {
        if (seenArmor.containsKey(armorHash)) false else {
            seenArmor[armorHash] = true
            true
        }
    }

    private fun currentSession(): Session? = synchronized(lock) {
        session?.takeIf { !it.destroyed }
    }

    private fun emitEvent(payload: JSONObject) {
        val out = JSONObject().put("action", "chatModuleEvent").put("event", payload)
        main.post {
            try {
                nativeObserver?.invoke(out)
            } catch (e: Exception) {
                Log.w(TAG, "observer failed: ${e.message}")
            }
            try {
                emitFn?.invoke(out)
            } catch (e: Exception) {
                Log.w(TAG, "emit failed: ${e.message}")
            }
        }
    }

    private fun ack(reqId: Int, ok: Boolean, result: Any? = null, error: String? = null) {
        if (reqId < 0) return
        val payload = JSONObject().put("type", "ack").put("reqId", reqId).put("ok", ok)
        if (ok && result != null) payload.put("result", result)
        if (!ok) payload.put("error", error ?: "error")
        emitEvent(payload)
    }

    private fun statusPayload(status: String, detail: String?): JSONObject =
        JSONObject().put("status", status).also { if (!detail.isNullOrBlank()) it.put("detail", detail) }

    private fun objects(arr: JSONArray): List<JSONObject> =
        (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }

    private fun parseNodes(raw: JSONArray): List<Node> {
        // The PWA `nodeInfo` carries `ip_addr`, native roster rows carry `ip`. A row with only a
        // domain is resolved through the chain roster in the store; without an IP an entry can
        // never be reached over HTTP.
        val rosterIpByDomain = HashMap<String, String>()
        appContext?.let { ctx ->
            for (kn in BeamioChatPgpStore.loadSiNodes(ctx)) {
                if (kn.domain.isNotEmpty()) rosterIpByDomain[kn.domain.uppercase()] = kn.ip
            }
        }
        val out = ArrayList<Node>()
        for (i in 0 until raw.length()) {
            val n = raw.optJSONObject(i) ?: continue
            var ip = n.optString("ip", "").ifBlank { n.optString("ip_addr", "") }
            val domain = n.optString("domain", "")
            if (BeamioSiCipherPost.normalizeIp(ip) == null && domain.isNotEmpty()) {
                rosterIpByDomain[domain.uppercase()]?.let { ip = it }
            }
            if (ip.isEmpty() && domain.isEmpty()) continue
            out.add(
                Node(
                    ip = ip,
                    domain = domain,
                    region = n.optString("region", ""),
                    armoredPublicKey = n.optString("armoredPublicKey", "")
                        .ifBlank { n.optString("pgpPublicKeyArmored", "") },
                ),
            )
        }
        return out
    }

    private fun normalizeAddress(raw: String): String = raw.trim().lowercase()

    private fun extractSendId(plaintext: String): String? {
        val obj = try {
            JSONObject(plaintext)
        } catch (_: Exception) {
            return null
        }
        obj.optString("sendId", "").takeIf { it.isNotEmpty() }?.let { return it }
        val inner = obj.optString("text", "")
        return try {
            JSONObject(inner).optString("sendId", "").takeIf { it.isNotEmpty() }
        } catch (_: Exception) {
            null
        }
    }
}
