/**
 * Automatically generated file. DO NOT MODIFY
 */
package network.conet.chat;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "network.conet.chat";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final boolean HISTORY_WRITES = true;
  // Field from default config.
  public static final boolean NATIVE_KEYS_QA = false;
  // Field from default config.
  public static final String VERSION_NAME = "0.2.22";
  // Field from default config.
  public static final boolean WALLET_CREDENTIAL_QA = false;
}
